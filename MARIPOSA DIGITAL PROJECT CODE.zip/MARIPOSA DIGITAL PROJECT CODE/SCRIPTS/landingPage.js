//Function that redirects to login page depending on the specific type of user
function redirectToLogin() {
    let loginPage = document.getElementById("loginAs").value;
    if (loginPage) {
        window.location.href = loginPage;
    }
}