/* //Client User Containers */
/* if(JSON.parce(localStorage.getItem("strRegisteredUsers")) === null){ */
    localStorage.setItem("strRegisteredUsers", JSON.stringify([])); 
/* } */

function registerUser() {
    let listOfContractSigningDates = []
    localStorage.setItem("strListOfContractSigningDates", JSON.stringify(listOfContractSigningDates))
    

    let userName = document.querySelector('#username');
    let passWord = document.querySelector('#password');
    let email = document.querySelector('#email');
    let firstName = document.querySelector('#fName');
    let lastName = document.querySelector('#lName');
    let mobNumber = document.querySelector('#mobNumber');

    let newUser = new Object();

    newUser.username = userName.value;
    newUser.password = passWord.value;
    newUser.email = email.value;
    newUser.firstname = firstName.value;
    newUser.lastname = lastName.value;
    newUser.mobilenumber = mobNumber.value;
    newUser.clientCart = [];
    newUser.reservedLots = [];
    newUser.checkoutProducts = [];
    newUser.lotContractSigningDates = [];
    newUser.pendingOrders = [];


    let registeredUsers = JSON.parse(localStorage.getItem("strRegisteredUsers"));

    if (!registeredUsers) {
        registeredUsers = [];
    }

    registeredUsers.push(newUser);
    alert("Account Registered")
    localStorage.setItem("strRegisteredUsers", JSON.stringify(registeredUsers));
}

//Function that redirects to login page depending on the specific type of user
function redirectToLogin() {
    let loginPage = document.getElementById("loginAs").value;
    if (loginPage) {
        window.location.href = loginPage;
    }
}


// function remItem(){
//     localStorage.removeItem("")
// }