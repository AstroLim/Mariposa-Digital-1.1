let mainAdminUser = {
    courierID:1,
    username:"Lander Suarez",
    password: "12345",
    email: "suarez@gmail.com",
    firstname:"Lander",
    lastname: "Suarez",
    mobilenumber: "01896445342",
}

let registeredMainAdminUsers = []
registeredMainAdminUsers.push(mainAdminUser);
localStorage.setItem("strRegisteredMainAdminUsers", JSON.stringify(registeredMainAdminUsers));

function loginAccount() {
    let loginEmail = document.querySelector('#inputEmail').value.trim();
    let loginPassWord = document.querySelector('#inputPassword').value.trim();

    let registeredMainAdminUsers = JSON.parse(localStorage.getItem("strRegisteredMainAdminUsers"));

    if (registeredMainAdminUsers) {
        for (let i = 0; i < registeredMainAdminUsers.length; i++) {
            if (registeredMainAdminUsers[i].email === loginEmail && registeredMainAdminUsers[i].password === loginPassWord) {
                alert(`Welcome Back Sir ${registeredMainAdminUsers[i].firstname}`);
                localStorage.setItem("strLoginAccount", JSON.stringify(registeredMainAdminUsers[i])); 
                window.location.href = "http://127.0.0.1:5500/STRUCTURES/ma-home-page.html";
                return;
            }
        }

        alert(`Invalid Email or Password`); 
    } 

    else {
        alert("No main admin account found."); 
    }
}